/**
 * Predmet: IFJ / IAL
 * Projekt: Implementace interpretu imperativniho jazyka
 * Variant: b/1/I
 * Subor:   interpret.h
 * Datum:   10.10.2011
 * Autori:  Bambusek David  <xbambu02@stud.fit.vutbr.cz>,
 *          Klvana Martin   <xklvan00@stud.fit.vutbr.cz>,
 *          Konar David     <xkonar07@stud.fit.vutbr.cz>,
 *          Marecek Matej   <xmarec12@stud.fit.vutbr.cz>,
 *          Szabo Peter     <xszabo06@stud.fit.vutbr.cz>
 */


#pragma once

#include <math.h>
#include "tagenerator.h"
#include "ial.h"

void interpret(TA_Item **ta_table, tBTSUzolPtr root);
void destroy_labels(int *jump_array);
void find_labels(TA_Item **ta_table, int **jump_array);
